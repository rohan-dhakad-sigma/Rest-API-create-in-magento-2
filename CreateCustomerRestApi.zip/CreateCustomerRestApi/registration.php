<?php
/**
 * Register your module
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sigma_CreateCustomerRestApi',
    __DIR__
);